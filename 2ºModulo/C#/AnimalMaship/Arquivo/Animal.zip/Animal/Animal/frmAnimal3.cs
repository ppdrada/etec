﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Animal
{
    public partial class frmAnimal3 : Form
    {
        public frmAnimal3()
        {
            InitializeComponent();
        }

        private void frmAnimal3_Load(object sender, EventArgs e)
        {

        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {
            
        }

        private void leãoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BackgroundImage = Bitmap.FromFile("D:\\imgAnimal\\leao.jpg");
        }

        private void cachorroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BackgroundImage = Bitmap.FromFile("D:\\imgAnimal\\dog.jpg");
        }

        private void elefanteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BackgroundImage = Bitmap.FromFile("D:\\imgAnimal\\elefante.jpg");
        }

        private void girafaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BackgroundImage = Bitmap.FromFile("D:\\imgAnimal\\girafa.jpg");
        }

        private void gatoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BackgroundImage = Bitmap.FromFile("D:\\imgAnimal\\gato.jpg");
        }

        private void con(object sender, EventArgs e)
        {
            
        }

        private void coalaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BackgroundImage = Bitmap.FromFile("D:\\imgAnimal\\Koala.jpg");
        }
    }
}
