﻿namespace Animal
{
    partial class frmAnimal3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.leãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cachorroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.elefanteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.girafaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gatoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.coalaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.leãoToolStripMenuItem,
            this.cachorroToolStripMenuItem,
            this.elefanteToolStripMenuItem,
            this.girafaToolStripMenuItem,
            this.gatoToolStripMenuItem,
            this.coalaToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(124, 136);
            this.contextMenuStrip1.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStrip1_Opening);
            // 
            // leãoToolStripMenuItem
            // 
            this.leãoToolStripMenuItem.Name = "leãoToolStripMenuItem";
            this.leãoToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.leãoToolStripMenuItem.Text = "Leão";
            this.leãoToolStripMenuItem.Click += new System.EventHandler(this.leãoToolStripMenuItem_Click);
            // 
            // cachorroToolStripMenuItem
            // 
            this.cachorroToolStripMenuItem.Name = "cachorroToolStripMenuItem";
            this.cachorroToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.cachorroToolStripMenuItem.Text = "Cachorro";
            this.cachorroToolStripMenuItem.Click += new System.EventHandler(this.cachorroToolStripMenuItem_Click);
            // 
            // elefanteToolStripMenuItem
            // 
            this.elefanteToolStripMenuItem.Name = "elefanteToolStripMenuItem";
            this.elefanteToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.elefanteToolStripMenuItem.Text = "Elefante";
            this.elefanteToolStripMenuItem.Click += new System.EventHandler(this.elefanteToolStripMenuItem_Click);
            // 
            // girafaToolStripMenuItem
            // 
            this.girafaToolStripMenuItem.Name = "girafaToolStripMenuItem";
            this.girafaToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.girafaToolStripMenuItem.Text = "Girafa";
            this.girafaToolStripMenuItem.Click += new System.EventHandler(this.girafaToolStripMenuItem_Click);
            // 
            // gatoToolStripMenuItem
            // 
            this.gatoToolStripMenuItem.Name = "gatoToolStripMenuItem";
            this.gatoToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.gatoToolStripMenuItem.Text = "Gato";
            this.gatoToolStripMenuItem.Click += new System.EventHandler(this.gatoToolStripMenuItem_Click);
            // 
            // coalaToolStripMenuItem
            // 
            this.coalaToolStripMenuItem.Name = "coalaToolStripMenuItem";
            this.coalaToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.coalaToolStripMenuItem.Text = "Coala";
            this.coalaToolStripMenuItem.Click += new System.EventHandler(this.coalaToolStripMenuItem_Click);
            // 
            // frmAnimal3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Animal.Properties.Resources.gato;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(644, 444);
            this.ContextMenuStrip = this.contextMenuStrip1;
            this.Name = "frmAnimal3";
            this.Text = "frmAnimal3";
            this.Load += new System.EventHandler(this.frmAnimal3_Load);
            this.ContextMenuStripChanged += new System.EventHandler(this.con);
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem leãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cachorroToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem elefanteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem girafaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gatoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem coalaToolStripMenuItem;
    }
}