﻿namespace Animal
{
    partial class FRManimal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FRManimal));
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.lemoreToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.esquiloToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sarueToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tartarugaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lemoreToolStripMenuItem,
            this.esquiloToolStripMenuItem,
            this.sarueToolStripMenuItem,
            this.tartarugaToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(125, 92);
            // 
            // lemoreToolStripMenuItem
            // 
            this.lemoreToolStripMenuItem.Name = "lemoreToolStripMenuItem";
            this.lemoreToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.lemoreToolStripMenuItem.Text = "Lemore";
            this.lemoreToolStripMenuItem.Click += new System.EventHandler(this.lemoreToolStripMenuItem_Click);
            // 
            // esquiloToolStripMenuItem
            // 
            this.esquiloToolStripMenuItem.Name = "esquiloToolStripMenuItem";
            this.esquiloToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.esquiloToolStripMenuItem.Text = "Esquilo";
            this.esquiloToolStripMenuItem.Click += new System.EventHandler(this.esquiloToolStripMenuItem_Click);
            // 
            // sarueToolStripMenuItem
            // 
            this.sarueToolStripMenuItem.Name = "sarueToolStripMenuItem";
            this.sarueToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.sarueToolStripMenuItem.Text = "Sarue";
            this.sarueToolStripMenuItem.Click += new System.EventHandler(this.sarueToolStripMenuItem_Click);
            // 
            // tartarugaToolStripMenuItem
            // 
            this.tartarugaToolStripMenuItem.Name = "tartarugaToolStripMenuItem";
            this.tartarugaToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.tartarugaToolStripMenuItem.Text = "Tartaruga";
            this.tartarugaToolStripMenuItem.Click += new System.EventHandler(this.tartarugaToolStripMenuItem_Click);
            // 
            // FRManimal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.ContextMenuStrip = this.contextMenuStrip1;
            this.DoubleBuffered = true;
            this.Name = "FRManimal";
            this.Text = "Animal11";
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem lemoreToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem esquiloToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sarueToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tartarugaToolStripMenuItem;
    }
}