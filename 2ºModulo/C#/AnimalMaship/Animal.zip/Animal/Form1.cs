﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Animal
{
    public partial class FRMprincipal : Form
    {
        public FRMprincipal()
        {
            InitializeComponent();
        }

        private void FRMprincipal_Load(object sender, EventArgs e)
        {

        }

        private void exibirAnimaisToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new FRManimal().Show();
        }
    }
}
