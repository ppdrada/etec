﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Animal
{
    public partial class FRManimal : Form
    {
        public FRManimal()
        {
            InitializeComponent();
        }

        private void lemoreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BackgroundImage = Bitmap.FromFile("c:/animais/lemore dançando.jpg");
        }

        private void esquiloToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BackgroundImage = Bitmap.FromFile("c:/animais/esquilo pare.jpg");
        }

        private void sarueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BackgroundImage = Bitmap.FromFile("c:/animais/é o que!!!!.jpg");
        }

        private void tartarugaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BackgroundImage = Bitmap.FromFile("c:/animais/download.jpg");
        }
    }
}
