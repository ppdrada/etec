﻿namespace Acervo
{
    partial class FrmPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Albuns = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Albuns
            // 
            this.Albuns.Location = new System.Drawing.Point(107, 151);
            this.Albuns.Name = "Albuns";
            this.Albuns.Size = new System.Drawing.Size(75, 23);
            this.Albuns.TabIndex = 0;
            this.Albuns.Text = "Álbuns";
            this.Albuns.UseVisualStyleBackColor = true;
            this.Albuns.Click += new System.EventHandler(this.Albuns_Click);
            // 
            // FrmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.Albuns);
            this.Name = "FrmPrincipal";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.FrmPrincipal_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Albuns;
    }
}

