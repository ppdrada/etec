﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Acervo
{
    public partial class FrmPrincipal : Form
    {
        public static MySqlConnection Conexao = new MySqlConnection("server=localhost;database=play;uid=root;sslmode=none");
        public FrmPrincipal()
        {
            InitializeComponent();
        }

        private void FrmPrincipal_Load(object sender, EventArgs e)
        {
            Conexao.Open();
            MessageBox.Show("Abriu");
        }

        private void Albuns_Click(object sender, EventArgs e)
        {
            new FrmAlbuns().ShowDialog();
        }
    }
}
