﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;



namespace cadastroRegioes
{
    public partial class frmcadastroCidade : Form
    {
        public frmcadastroCidade()
        {
            InitializeComponent();
        }
        public static String Estado;

       

        private void frmcadastroCidade_Load(object sender, EventArgs e)
        {
            
            buscar();
            this.BackgroundImage = Image.FromFile("C:/Users/pedro/OneDrive/Área de Trabalho/Brasil/Estados/"+Estado+".jpg");
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {          

            MySqlCommand MeuComando = new MySqlCommand();
            MeuComando.CommandText = "insert into cidade(CID_NOME, CID_POPULACAO)" +
                "values (@cidade, @populacao)";

            MeuComando.Connection = Form1.conexao;

            MeuComando.Parameters.Add("@cidade", MySqlDbType.VarChar).Value = txtcidade.Text;
            MeuComando.Parameters.Add("@populacao", MySqlDbType.Int32).Value = nudPopulacao.Value;
           


            MeuComando.ExecuteNonQuery();

            
        }

        private void buscar()
        {
            MySqlDataAdapter oTab = new MySqlDataAdapter("Select cid_nome Nome,cid_estado Estado, cid_populacao Populacao  from cidade where cid_estado = '" + Estado +"'", Form1.conexao);
            DataTable oDados = new DataTable();
            //oTab.Fill(oDados);
            dtCidade.DataSource = oDados;
        }
    }
}
